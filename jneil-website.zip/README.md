# J.Neil Construction & Real Estate

Welcome to the official website of **J.Neil Construction & Real Estate** — a Nigerian-owned firm delivering modern, colorful, and creative housing solutions.

🌐 Visit the site: [Live Website](https://yourusername.github.io/jneil-website/)

Features:
- Interactive 2D landing page
- Project gallery
- Feedback form
- Blog section
- Design submission tool

📧 Contact: jneilconstruction@gmail.com  
📸 Instagram: @jneil_constrution  
📞 09038775222 | 08087904738
